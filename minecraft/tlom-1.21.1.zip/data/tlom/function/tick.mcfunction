say test1
effect give @a jump_boost